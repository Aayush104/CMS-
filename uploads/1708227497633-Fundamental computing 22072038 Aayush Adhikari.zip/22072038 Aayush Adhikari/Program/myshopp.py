import sys
import purchased
import sell
import time

def print_slow(str):
    for letter in str:
        print(letter, end='')
        time.sleep(0.03)



def option():
    
    print_slow("\n\n")
    print_slow("\t\t\t\t\t\t\t\t\t****************************************\n")
    print_slow("\t\t\t\t\t\t\t\t\t*     Welcome to Durga Electronics      *\n")
    print_slow("\t\t\t\t\t\t\t\t\t****************************************\n\n\n")
    print_slow("Hello buddy!! What's up?\n\n")
    print("Buy Or sell you can choose option from below:\n")
    print("Click (1): For laptop selling\n")
    print("Click (2): For buying laptop\n")
    print("Click (3): To exit\n")
    choice = input("What do you want to do? ")

    if choice == "1":
            sell.detail()
            
    elif choice == "2":
            purchased.purchase()
            
    elif choice == "3":
            print("You have choosen to exit.....")  
            sys.exit()
            
    else:
         print("Hahaha buddy you choosed Invalid option!! Please choose either 'sell', 'buy' or 'exit'.")
         option()
         
    
option()
