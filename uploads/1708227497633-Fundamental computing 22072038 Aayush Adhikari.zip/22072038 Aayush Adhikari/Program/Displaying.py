#function display
def display():
    #empty dictionary name stock
    stock = {}
    #opening laptop.txt file in read mode
    with open('durga.txt', 'r') as details:
        # for each loop hat iterates over each line in the file
        for lines in details:
            # split the word after comma(,)
            product, brand, price, quantity, model, graphic = lines.strip().split(',')
            stock[product.upper()] = {'brand': brand, 'price': float(price.replace('$', '')), 'quantity': int(quantity), 'model': model, 'graphic': graphic}
    return stock # returns to dictionary stock containing all the necessary product information
