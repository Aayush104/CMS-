import Displaying
import datetime
def purchase():

     # Displaying the details of available laptops
    print("\t\t\t\t\t\t*     Items we have    *\n")
    print("\t\t*********************************************************************************************")
    print("\t\t S.N    Laptop Name        Brand             Price             Model             Graphics")
    print("\t\t*********************************************************************************************")
    print("\t\t 1      RAZER BLADE        Razer             $2000.00        i7 7th Gen          GTX 3060")
    print("\t\t---------------------------------------------------------------------------------------------")
    print("\t\t 2      XPS                Dell              $1976.00        i5 9th Gen          GTX 3070")
    print("\t\t---------------------------------------------------------------------------------------------")
    print("\t\t 3      ALIENWARE          Alienware         $1978.00        i5 9th Gen          GTX 3070")
    print("\t\t---------------------------------------------------------------------------------------------")
    print("\t\t 4      SWIFT 7            Acer              $900.00         i5 9th Gen          GTX 3070")
    print("\t\t---------------------------------------------------------------------------------------------")
    print("\t\t 5      MACBOOKPRO 16      Apple             $3500.00        i5 9th Gen          GTX 3070")
    print("\t\t*********************************************************************************************")
    # Getting display function 
    stock = Displaying.display()
     # Getting the distributor details
    seller = str(input("Enter Distributor name: "))
    address = str (input("Enter Distributor address: "))
 
    
    while True:
        name_of_laptop = input("Enter the name of laptop: ")

        if name_of_laptop.upper() not in stock:
            print("Sorry! We can't provide you this item please select items from table displayed.")
        else:
            break

   
    while True:
        try:
            no_of_laptops = int(input("Enter the number of laptops: "))
            if no_of_laptops <= 0:
                print("Please try again and enter a positive value while demanding quantity.")
            else:
                break
        except:
            print("Try again and enter an integer value.")

    # updating stock  
    stock[name_of_laptop.upper()]['quantity'] += no_of_laptops
    Sub_total = stock[name_of_laptop.upper()]['price'] * no_of_laptops
    #adding vat amount
    VAT_amount = 0.13 * Sub_total
    # total amount with vat
    Total = Sub_total + VAT_amount

  # Creating the invoice
    txt_file = f"""
                                    **********************************************
                                        *           Durga Electronics           *
                                                    Duhabi-5,Sunsari
                                                        Nepal
                                    **********************************************
                                -----------------------------------------------------
                                                        INVOICE
                                ------------------------------------------------------
                                                   Date:{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
                                       Distributor Name: {seller.upper()}
                                    Distributor address: {address.upper()}
                                           Product Name: {name_of_laptop.upper()}
                                         Price per Unit: ${stock[name_of_laptop.upper()]['price']:.2f}
                                                  Brand: {stock[name_of_laptop.upper()]['brand']}
                                                  Model: {stock[name_of_laptop.upper()]['model']}
                                               Graphics: {stock[name_of_laptop.upper()]['graphic']}
                                               Quantity: {no_of_laptops}
                                Total cost With out VAT: ${Sub_total:.2f}
                       ******************************************************************************* 
                                    Total Cost With VAT: ${Total:.2f} 
                        *******************************************************************************          
                        """
    print(txt_file)     
 # Updating the stock details
    with open(f"{seller}LaptopsBuy.txt", "w") as bill:
            bill.write(txt_file)
            print('\t\t\t\t\t<<<A bill has generated as Text file>>>\n')
            with open('durga.txt', 'w') as bill:
                for name_of_laptop, details in stock.items():
                    name = name_of_laptop
                    brand = details['brand']
                    price = details['price']
                    quantity = details['quantity']
                    model = details['model']
                    graphic = details['graphic']
                    bill.write(f"{name},{brand},${price:.2f},{quantity},{model},{graphic}\n")
#  returning values to stock after updating Laptop.txt
    return stock